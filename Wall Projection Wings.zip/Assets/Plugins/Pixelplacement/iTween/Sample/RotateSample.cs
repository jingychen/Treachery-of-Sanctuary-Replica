using UnityEngine;
using System.Collections;

public class RotateSample : MonoBehaviour
{	
	void Start(){
		iTween.RotateTo(gameObject, iTween.Hash("z", 100, "easeType", "spring", "loopType", "none", "delay", .4, "speed",50));
	}
}

