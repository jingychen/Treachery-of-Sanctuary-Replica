﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveDisplay : MonoBehaviour {

	public GameObject CentreJoint;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
		transform.position = new Vector3 (CentreJoint.transform.position.x, 
			CentreJoint.transform.position.y, 
			CentreJoint.transform.position.z);

	}
}
