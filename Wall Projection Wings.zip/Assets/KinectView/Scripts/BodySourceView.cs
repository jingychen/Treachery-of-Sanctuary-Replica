﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Kinect = Windows.Kinect;
using Windows.Kinect;

public class BodySourceView : MonoBehaviour 
{
	struct Point
	{
		public int x, y;
	}
    public Material BoneMaterial;
    public GameObject BodySourceManager;
    
    private Dictionary<ulong, GameObject> _Bodies = new Dictionary<ulong, GameObject>();
    private BodySourceManager _BodyManager;
	private KinectSensor _Sensor;

	public GameObject WingsObj;
	//---------Right Wing joints-------//
	public GameObject RjointSpine;
	public GameObject RjointElbow;
	public GameObject RjointWrist;


	//--------Left Wing joints---------//
	public GameObject LjointSpine;
	public GameObject LjointElbow;
	public GameObject LjointWrist;



	//Elbow Transform

	private bool LElbowInitial = false;
	private bool RElbowInitial = false;

	//RotateEmptyObj
	private GameObject LRotateTo;
	private GameObject RRotateTo;

	// Maximum turn rate in degrees per second.
	public float turningRate = 30f; 
	// Rotation we should blend towards.
	private Quaternion _targetRotation = Quaternion.identity;

	private ulong ActiveID = 0; 
	private bool ActiveExists = false;



    private Dictionary<Kinect.JointType, Kinect.JointType> _BoneMap = new Dictionary<Kinect.JointType, Kinect.JointType>()
    {
        { Kinect.JointType.FootLeft, Kinect.JointType.AnkleLeft },
        { Kinect.JointType.AnkleLeft, Kinect.JointType.KneeLeft },
        { Kinect.JointType.KneeLeft, Kinect.JointType.HipLeft },
        { Kinect.JointType.HipLeft, Kinect.JointType.SpineBase },
        
        { Kinect.JointType.FootRight, Kinect.JointType.AnkleRight },
        { Kinect.JointType.AnkleRight, Kinect.JointType.KneeRight },
        { Kinect.JointType.KneeRight, Kinect.JointType.HipRight },
        { Kinect.JointType.HipRight, Kinect.JointType.SpineBase },
        
        { Kinect.JointType.HandTipLeft, Kinect.JointType.HandLeft },
        { Kinect.JointType.ThumbLeft, Kinect.JointType.HandLeft },
        { Kinect.JointType.HandLeft, Kinect.JointType.WristLeft },
        { Kinect.JointType.WristLeft, Kinect.JointType.ElbowLeft },
        { Kinect.JointType.ElbowLeft, Kinect.JointType.ShoulderLeft },
        { Kinect.JointType.ShoulderLeft, Kinect.JointType.SpineShoulder },
        
        { Kinect.JointType.HandTipRight, Kinect.JointType.HandRight },
        { Kinect.JointType.ThumbRight, Kinect.JointType.HandRight },
        { Kinect.JointType.HandRight, Kinect.JointType.WristRight },
        { Kinect.JointType.WristRight, Kinect.JointType.ElbowRight },
        { Kinect.JointType.ElbowRight, Kinect.JointType.ShoulderRight },
        { Kinect.JointType.ShoulderRight, Kinect.JointType.SpineShoulder },
        
        { Kinect.JointType.SpineBase, Kinect.JointType.SpineMid },
        { Kinect.JointType.SpineMid, Kinect.JointType.SpineShoulder },
        { Kinect.JointType.SpineShoulder, Kinect.JointType.Neck },
        { Kinect.JointType.Neck, Kinect.JointType.Head },
    };
	void Start(){
		_Sensor = KinectSensor.GetDefault();
		if (_Sensor != null)
		{
			



			if (!_Sensor.IsOpen)
			{
				_Sensor.Open();
			}
		}

		LRotateTo = new GameObject();
		RRotateTo = new GameObject ();
	}
    void Update () 
    {
        if (BodySourceManager == null)
        {
            return;
        }
        
        _BodyManager = BodySourceManager.GetComponent<BodySourceManager>();
        if (_BodyManager == null)
        {
            return;
        }
        
        Kinect.Body[] data = _BodyManager.GetData();
        if (data == null)
        {
            return;
        }
        
        List<ulong> trackedIds = new List<ulong>();
        foreach(var body in data)
        {
            if (body == null)
            {
                continue;
              }
                
            if(body.IsTracked)
            {
                trackedIds.Add (body.TrackingId);
				if (ActiveExists == false) {
					ActiveID = body.TrackingId;
				}
            }
        }
        
        List<ulong> knownIds = new List<ulong>(_Bodies.Keys);
        
        // First delete untracked bodies
        foreach(ulong trackingId in knownIds)
        {
            if(!trackedIds.Contains(trackingId))
            {
				if (trackingId == ActiveID) {
					ActiveExists = false;
					WingsObj.SetActive (false);
				}
                Destroy(_Bodies[trackingId]);
                _Bodies.Remove(trackingId);
            }
        }

        foreach(var body in data)
        {
            if (body == null)
            {
                continue;
            }
            
            if(body.IsTracked)
            {
                if(!_Bodies.ContainsKey(body.TrackingId))
                {
                    _Bodies[body.TrackingId] = CreateBodyObject(body.TrackingId);
                }
                
                RefreshBodyObject(body, _Bodies[body.TrackingId]);
            }
        }
    }
    
    private GameObject CreateBodyObject(ulong id)
    {
        GameObject body = new GameObject("Body:" + id);
        
        for (Kinect.JointType jt = Kinect.JointType.SpineBase; jt <= Kinect.JointType.ThumbRight; jt++)
        {
            GameObject jointObj = GameObject.CreatePrimitive(PrimitiveType.Cube);

            //LineRenderer lr = jointObj.AddComponent<LineRenderer>();
           // lr.SetVertexCount(2);
            //lr.material = BoneMaterial;
            //lr.SetWidth(0.05f, 0.05f);
            
            jointObj.transform.localScale = new Vector3(0f, 0f, 0f);
            jointObj.name = jt.ToString();
            jointObj.transform.parent = body.transform;
        }
        
        return body;
    }

    private void RefreshBodyObject(Kinect.Body body, GameObject bodyObject)
    {
        for (Kinect.JointType jt = Kinect.JointType.SpineBase; jt <= Kinect.JointType.ThumbRight; jt++)
        {
            Kinect.Joint sourceJoint = body.Joints[jt];
            Kinect.Joint? targetJoint = null;
            
            if(_BoneMap.ContainsKey(jt))
            {
                targetJoint = body.Joints[_BoneMap[jt]];
            }
            
            Transform jointObj = bodyObject.transform.Find(jt.ToString());

			//------------------
			// 3D coordinates in meters
			CameraSpacePoint cameraPoint = sourceJoint.Position;



			// 2D coordinates in pixels

			ColorSpacePoint colorPoint = _Sensor.CoordinateMapper.MapCameraPointToColorSpace(cameraPoint);

			DepthSpacePoint depthPoint = _Sensor.CoordinateMapper.MapCameraPointToDepthSpace(cameraPoint);


			//------------------

            //jointObj.localPosition = GetVector3FromJoint(sourceJoint);
		

			if (colorPoint.X.ToString () != "-Infinity") {

				jointObj.localPosition = GetVector3FromJoint (sourceJoint, colorPoint);



				//LineRenderer lr = jointObj.GetComponent<LineRenderer> ();
				if (targetJoint.HasValue) {
					Kinect.Joint Joint2 = (Kinect.Joint)targetJoint;
					CameraSpacePoint cameraPoint2 = Joint2.Position;

					ColorSpacePoint colorPoint2 = _Sensor.CoordinateMapper.MapCameraPointToColorSpace(cameraPoint);
					//lr.SetPosition (0, jointObj.localPosition);

					if (ActiveID == body.TrackingId) {
						WingsObj.SetActive (true);
						//---------------Right wing-------------//

						if (jt.ToString () == Kinect.JointType.SpineShoulder.ToString ()) {

							SetRSpine (jointObj);
						}

						if (jt.ToString () == Kinect.JointType.ElbowRight.ToString ()) {
							SetRElbow (jointObj);
						}


						if (jt.ToString () == Kinect.JointType.WristRight.ToString ()) {
							SetRWrist (jointObj);

						}



						//---------------Left wing-------------//
						if (jt.ToString () == Kinect.JointType.SpineShoulder.ToString ()) {
							SetLSpine (jointObj);
						}

						if (jt.ToString () == Kinect.JointType.ElbowLeft.ToString ()) {

							SetLElbow (jointObj);
						}


						if (jt.ToString () == Kinect.JointType.WristLeft.ToString ()) {

							SetLWrist (jointObj);

						}



					}

					//lr.SetPosition (1, GetVector3FromJoint (targetJoint.Value, colorPoint2));
					//lr.SetColors (GetColorForState (sourceJoint.TrackingState), GetColorForState (targetJoint.Value.TrackingState));
				} else {
					//lr.enabled = false;
				}


			}

        }
    }
    
    private static Color GetColorForState(Kinect.TrackingState state)
    {
        switch (state)
        {
        case Kinect.TrackingState.Tracked:
            return Color.green;

        case Kinect.TrackingState.Inferred:
            return Color.red;

        default:
            return Color.black;
        }
    }
    
    private static Vector3 GetVector3FromJoint(Kinect.Joint joint , ColorSpacePoint csp)
    {
		
		return new Vector3(csp.X , -csp.Y  , 0.1f  );
		//return new Vector3(joint.Position.X *5 , joint.Position.Y *5  , joint.Position.Z  *17 );
    }

	//-------------Right wing functions-----------//
	private void SetRSpine(Transform RJoint){
		
		RjointSpine.transform.position = new Vector3 (RJoint.position.x,
			RJoint.position.y,
			RJoint.position.z);
		


	}

	private void SetRElbow(Transform RJoint){
		
		RjointElbow.transform.position= new Vector3 (RJoint.position.x,
			RJoint.position.y,
			RJoint.position.z);


		if (RElbowInitial == false) {
			RjointElbow.transform.rotation = new Quaternion (RJoint.rotation.x,
				RJoint.rotation.y,
				RJoint.rotation.z,
				RJoint.rotation.w);
			RElbowInitial = true;
		}

	}
	private void SetRWrist(Transform RJoint){
		
		float JointAngle = CalcAngle (RJoint,RjointElbow.transform);
		JointAngle = (JointAngle + 360) % 360;
		float WingAngle = CalcAngle (RjointWrist.transform, RjointElbow.transform);
		WingAngle = (WingAngle + 360) % 360;



		float AngleDiff = JointAngle - WingAngle;


		RRotateTo.transform.rotation = new Quaternion (RjointElbow.transform.rotation.x,
			RjointElbow.transform.rotation.y,
			RjointElbow.transform.rotation.z,
			RjointElbow.transform.rotation.w);

		RRotateTo.transform.Rotate (transform.forward, AngleDiff);


		RjointElbow.transform.rotation = Quaternion.Slerp (RjointElbow.transform.rotation, RRotateTo.transform.rotation, Time.deltaTime * 10);

	}
		
	//-------------Left wing functions-----------//
	private void SetLSpine(Transform LJoint){
		LjointSpine.transform.position = new Vector3 (LJoint.position.x,
			LJoint.position.y,
			LJoint.position.z);


	}

	private void SetLElbow(Transform LJoint){
		
		LjointElbow.transform.position= new Vector3 (LJoint.position.x,
			LJoint.position.y,
			LJoint.position.z);


		if (LElbowInitial == false) {
			LjointElbow.transform.rotation = new Quaternion (LJoint.rotation.x,
				LJoint.rotation.y,
				LJoint.rotation.z,
				LJoint.rotation.w);
			LElbowInitial = true;
		}


	}
	private void SetLWrist(Transform LJoint){
		


		float JointAngle = CalcAngle (LJoint,LjointElbow.transform);
		JointAngle = (JointAngle + 360) % 360;
		float WingAngle = CalcAngle (LjointWrist.transform, LjointElbow.transform);
		WingAngle = (WingAngle + 360) % 360;


		float AngleDiff = JointAngle - WingAngle;

		LRotateTo.transform.rotation = new Quaternion (LjointElbow.transform.rotation.x,
			LjointElbow.transform.rotation.y,
			LjointElbow.transform.rotation.z,
			LjointElbow.transform.rotation.w);
		
		LRotateTo.transform.Rotate (transform.forward, AngleDiff);

		LjointElbow.transform.rotation = Quaternion.Slerp (LjointElbow.transform.rotation, LRotateTo.transform.rotation, Time.deltaTime * 10);


	}
			private float CalcAngle(Transform WristJoint, Transform ElbowJoint ){
				return Mathf.Rad2Deg * (Mathf.Atan2 (WristJoint.position.y - ElbowJoint.transform.position.y, WristJoint.position.x - ElbowJoint.transform.position.x));
	}


}
